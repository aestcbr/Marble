# Marble Theme Website

Simple marble-themed website project.

## Features
- Clean UI
- Responsive layout
- Minimal design

## How to Use
1. Open index.html in your browser
2. Customize content as needed

## Author
Your Name
